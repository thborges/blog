// Copyright (C) 2019 Thiago Borges de Oliveira

#include <pic16regs.h>
#include <stdint.h> 

// IO PORT the RADIO is connected to
#define SENDPORT RA5

#define GET(reg,bit) (((reg) >> (bit) ) & 1)
#define SET(reg,bit) (reg) |= (1<<(bit))
#define CLR(reg,bit) (reg) &= ~(1<<(bit))

// clear watch dog counter
#define clear_watch_dog __asm clrwdt __endasm
#define sleep __asm sleep __endasm

// Clock interno _INTRC_OSC_NOCLKOUT
// Disable watchdog _WDTE_OFF
// Disable MCLRE, RA3 used as INPUT
__code uint16_t __at (_CONFIG) __configword = _INTRC_OSC_NOCLKOUT & _WDTE_ON & _MCLRE_OFF;

// Uncalibrated delay_us
void delay_us(uint8_t us) {
	// 4 Mhz 16F device with no PLL can execute 4,000,000 / 4 = 1,000,000 
	// single word instructions per second (e.g. 1 uSec per instruction)
	uint8_t a = 7;
	us -= a; // initial attributions and loop test first time
	while(us >= a) {  // 4 instructions
		us -= a;      // 3 instructions
	}
/*	if (us & 2)  __asm nop __endasm;
	if (us & 4)  __asm nop, nop, nop, nop __endasm;
	if (us & 8)  __asm nop, nop, nop, nop __endasm;*/
}

// Uncalibrated delay_ms
void delay_ms(uint16_t ms)
{
	// Delay ms Milliseconds (1/1000 of a second)
	// Can delay from 1 to 32768 ms
	// This is NOT an exact delay routine!  
	// The inner loop is about 8 instructions, 
	// so the entire delay is a few uS over time.

	while(ms--)
	{
		clear_watch_dog;
		uint8_t tempcount = 125;	// This loop is about 8 instructions
		while(tempcount != 0)	// 125 loops is 1000 instructions
			tempcount--;	// Run at 4MHz is 1ms
	}
	clear_watch_dog;
}

uint8_t crc8(uint8_t *data, uint8_t len)
{
    uint8_t crc = 0xff;
    uint8_t i, j;
    for (i = 0; i < len; i++) {
        crc ^= data[i];
        for (j = 0; j < 8; j++) {
            if ((crc & 0x80) != 0)
                crc = (uint8_t)((crc << 1) ^ 0x31);
            else
                crc <<= 1;
        }
    }
    return crc;
}

void send_rf_preamble(uint8_t t)
{
	for(uint8_t i = 0; i < t; i++) {
		// make 250uS start bit first
		SENDPORT = 0;
		delay_us(170);
		SENDPORT = 1;
		delay_us(80);

		__asm clrwdt __endasm; // clear watch dog counter
	}
	SENDPORT = 0;
}

//=============================================================================
//   SEND_RF_BYTE
//   Based on the code from https://www.romanblack.com/RF/cheapRFmodules.htm
//=============================================================================
void send_rf_byte(unsigned char txdat)
{
	//-------------------------------------------------------
	// This is a pulse period encoded system to send a byte to RF module.
	// Bits are sent MSB first. Each byte sends 9 pulses (makes 8 periods).
	// Timing;
	//   HI pulse width; always 80uS
	//   0 bit, LO width; 20uS (total 0 bit pulse period 100uS)
	//   1 bit, LO width; 70uS (total 1 bit pulse period 150uS)
	//   space between bytes, LO width; 170uS (total space period 250uS)
	// (timings tested with 20MHz xtal PIC 18F, no pll)
	//-------------------------------------------------------

	unsigned char tbit;

	// make 250uS start bit first
	SENDPORT = 0;
	delay_us(170);      // 170uS LO
	SENDPORT = 1;
	delay_us(80);     // 80uS HI
	SENDPORT = 0;

	// now loop and send 8 bits
	for(tbit=0; tbit<8; tbit++)
	{
		delay_us(20);             // default 0 bit LO period is 20uS
		if (GET(txdat, 7)) delay_us(50);  // increase the LO period if is a 1 bit!
		SENDPORT = 1;
		delay_us(80);             // 80uS HI pulse
		SENDPORT = 0;
		txdat <<= 1;              // roll data byte left to get next bit
	}
}
//-----------------------------------------------------------------------------

void setup(void) {
	ANSEL = 0;     // digital IO on PORTA
	CMCON = 0b111; // disable comparator
	ADON  = 0;     // disable Analog-Digital converter

	NOT_RAPU = 0; // enable pull-up on PORTA

	// Watchdog setup
	clear_watch_dog;
	PSA = 1; // Prescaler is assigned to the WDT
	
	// Prescaler 1:4 (18ms x 4 = 72ms sleep duration)
	PS2 = 0;
	PS1 = 1;
	PS0 = 0;
	clear_watch_dog;

	TRISC = 0b00111111; // Pins on PORTC as input
	//PORTC didn't have pull-ups. Circuit has its own resistors

	WPUA  = 0b00010111; // Enable pull-up resistors on PORTA
	TRISA = 0b00010111; // Pins on PORTA as input, except RA3, RA5 (Connected to Radio)

	RA5 = 0; // LED starts off
}

void main(void)
{
	setup();

	/* command has 16 bits, from right to left:
		0: DOWN button was pressed if bit 0 is high
		1: UP
		2: LEFT
		3: RIGHT
		4: FWD
		5: BWD
		6: OPEN
		7: CLOSE
		8: AUX1
		9: AUX2
		10-15: NOT USED, always zero
	 */

	while (1) {
		// inverted logic, using pull-up
		uint8_t bcmd0 = 0;
		uint8_t bcmd1 = 0;
		uint8_t a = PORTA;
		uint8_t c = PORTC;
		if (!(a & _RA2)) bcmd0 |= 0b1;			//DOWN
		if (!(a & _RA0)) bcmd0 |= 0b10;			//UP
		if (!(a & _RA4)) bcmd0 |= 0b100;		//LEFT
		if (!(a & _RA1)) bcmd0 |= 0b1000;		//RIGHT
		if (!(c & _RC2)) bcmd0 |= 0b10000;		//FWD
		if (!(c & _RC0)) bcmd0 |= 0b100000;		// BWD
		if (!(c & _RC3)) bcmd0 |= 0b1000000;	// TURN CLOCKWISE
		if (!(c & _RC1)) bcmd0 |= 0b10000000;	// TURN COUNTER CLOCKWISE
		if (!(c & _RC5)) bcmd1 |= 0b1;			// AUX1
		if (!(c & _RC4)) bcmd1 |= 0b10;			// AUX2

		if (bcmd0 > 0 || bcmd1 > 0) {
			uint8_t bcmd[2] = {bcmd0, bcmd1};
			uint8_t crc = crc8(bcmd, 2);
			send_rf_preamble(10);
			send_rf_byte(bcmd[0]);
			send_rf_byte(bcmd[1]);
			send_rf_byte(crc);

			delay_ms(10);
		}
		else { // if not command, sleep!
			sleep;
			clear_watch_dog;
		}
	}
}
